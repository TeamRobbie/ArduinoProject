#sleep 60

sleep 20

~/code/cyclophone/startup/bananapi/startjacksc.sh

sleep 20

~/code/cyclophone/startup/bananapi/startcyclosensors.sh
~/code/cyclophone/startup/bananapi/startoscadaleds.sh

~/code/cyclophone/startup/bananapi/startscoscdir.sh
