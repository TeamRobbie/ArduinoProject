#sleep 60

~/code/cyclophone/startup/bananapi/startcyclosensors.sh
~/code/cyclophone/startup/bananapi/startoscadaleds.sh

~/code/cyclophone/startup/bananapi/startscoscdir.sh
