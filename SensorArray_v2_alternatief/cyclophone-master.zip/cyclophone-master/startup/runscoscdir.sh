# screen -d -m scoscdir 192.168.1.143 8000 ~/cyclophone_samples/mmap.hs 
scoscdir 192.168.1.143 8000 ~/cyclophone_samples/mmap.hs 
