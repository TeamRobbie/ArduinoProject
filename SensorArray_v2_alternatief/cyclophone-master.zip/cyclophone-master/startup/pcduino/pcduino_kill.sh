killall -9 jackd
killall scoscdir
killall ledoscserver
