screen -d -m ~/code/c_environment/ledoscserver/ledoscserver
