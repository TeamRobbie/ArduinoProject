~/code/cyclophone/startup/pcduino_startjacksc.sh
~/code/cyclophone/startup/pcduino_startledserver.sh
~/code/cyclophone/startup/pcduino_startscoscdir.sh
