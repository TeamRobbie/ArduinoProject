screen -d -m ~/.cabal/bin/scoscdir 192.168.8.121 8000 ~/cyclophone_samples/mmap.hs
