#!/bin/sh

chmod 660 /dev/spidev*
chgrp wheel /dev/spidev*
