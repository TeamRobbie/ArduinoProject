sh -x /home/bananapi/code/cyclophone/startup/bananapipro_arch/startfaust.sh
sh -x /home/bananapi/code/cyclophone/startup/bananapipro_arch/startcyclopass.sh
sh -x /home/bananapi/code/cyclophone/startup/bananapipro_arch/startcyclosensors.sh

#sh -x ~/code/cyclophone/startup/bananapipro_arch/startjacksc.sh
#sh -x ~/code/cyclophone/startup/bananapipro_arch/startoscadaleds.sh
#sh -x ~/code/cyclophone/startup/bananapipro_arch/startscoscdir.sh
# ~/code/cyclophone/startup/bananapipro_arch/startcyclosensors.sh
