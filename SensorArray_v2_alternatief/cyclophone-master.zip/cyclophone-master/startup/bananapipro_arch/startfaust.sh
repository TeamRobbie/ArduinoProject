screen -dmS faustprog sh -c 'fosc24.1 -osc --device hw:1'

# fosc24.1 -osc --device hw:1
