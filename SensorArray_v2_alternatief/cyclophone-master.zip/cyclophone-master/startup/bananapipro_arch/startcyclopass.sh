screen -dmS cyclopass sh -c 'cyclopass'

#cyclopass
