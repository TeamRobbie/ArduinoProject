screen -dmS oscadaleds sh -c '/home/bananapi/.cabal/bin/oscadaleds 192.168.8.180 8086 /dev/ttyACM0; exec bash'
