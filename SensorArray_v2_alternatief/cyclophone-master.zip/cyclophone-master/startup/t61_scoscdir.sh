screen -d -m scoscdir 192.168.123.111 8000 ~/cyclophone_samples/mmapfile.hs
