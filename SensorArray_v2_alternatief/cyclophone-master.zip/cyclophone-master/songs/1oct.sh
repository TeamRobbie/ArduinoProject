oscsend 192.168.8.174 8000 "scale" [11,0]

