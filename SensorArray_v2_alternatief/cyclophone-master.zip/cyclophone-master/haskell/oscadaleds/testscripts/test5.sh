oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
oscsend 127.0.0.1 8000 showarray [0]
oscsend 127.0.0.1 8000 showarray [2]
sleep 0.2
