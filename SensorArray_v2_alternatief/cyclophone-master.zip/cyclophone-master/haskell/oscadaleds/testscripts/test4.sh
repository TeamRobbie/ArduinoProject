
oscsend 127.0.0.1 8000 fadeto [0,200]
oscsend 127.0.0.1 8000 fadeto [2,200]
