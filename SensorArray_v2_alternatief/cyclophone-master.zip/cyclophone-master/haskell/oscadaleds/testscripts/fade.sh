oscsend 127.0.0.1 8000 showarray [3]
sleep 1
oscsend 127.0.0.1 8000 showarray [2]
sleep 1
oscsend 127.0.0.1 8000 showarray [1]
sleep 1

oscsend 127.0.0.1 8000 fadeto [3,1250]
oscsend 127.0.0.1 8000 fadeto [2,1250]
oscsend 127.0.0.1 8000 fadeto [1,1250]
oscsend 127.0.0.1 8000 fadeto [2,250]
oscsend 127.0.0.1 8000 fadeto [3,250]
oscsend 127.0.0.1 8000 fadeto [0,250]
oscsend 127.0.0.1 8000 fadeto [3,250]
oscsend 127.0.0.1 8000 fadeto [2,250]
oscsend 127.0.0.1 8000 fadeto [1,250]
oscsend 127.0.0.1 8000 fadeto [2,250]
oscsend 127.0.0.1 8000 fadeto [3,250]
oscsend 127.0.0.1 8000 fadeto [0,250]
