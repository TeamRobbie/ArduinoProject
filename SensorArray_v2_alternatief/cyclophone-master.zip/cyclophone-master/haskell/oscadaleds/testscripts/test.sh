
oscsend 127.0.0.1 8000 updatearray [0]
oscsend 127.0.0.1 8000 setpixel [0,100]
oscsend 127.0.0.1 8000 setpixel [1,1100]
oscsend 127.0.0.1 8000 setpixel [2,1200]
oscsend 127.0.0.1 8000 setpixel [3,1300]
oscsend 127.0.0.1 8000 setpixel [4,1400]
oscsend 127.0.0.1 8000 setpixel [5,1500]
oscsend 127.0.0.1 8000 setpixel [6,1600]
oscsend 127.0.0.1 8000 setpixel [7,1700]
oscsend 127.0.0.1 8000 setpixel [8,1800]
oscsend 127.0.0.1 8000 setpixel [9,1900]
oscsend 127.0.0.1 8000 setpixel [10,100]
oscsend 127.0.0.1 8000 setpixel [11,11100]
oscsend 127.0.0.1 8000 setpixel [12,11200]
oscsend 127.0.0.1 8000 setpixel [13,11300]
oscsend 127.0.0.1 8000 setpixel [14,11400]
oscsend 127.0.0.1 8000 setpixel [15,11500]
oscsend 127.0.0.1 8000 setpixel [16,11600]
oscsend 127.0.0.1 8000 setpixel [17,11700]
oscsend 127.0.0.1 8000 setpixel [18,11800]
oscsend 127.0.0.1 8000 setpixel [19,11900]

oscsend 127.0.0.1 8000 updatearray [1]
oscsend 127.0.0.1 8000 setpixel [0,21100]
oscsend 127.0.0.1 8000 setpixel [1,211100]
oscsend 127.0.0.1 8000 setpixel [2,211200]
oscsend 127.0.0.1 8000 setpixel [3,211300]
oscsend 127.0.0.1 8000 setpixel [4,211400]
oscsend 127.0.0.1 8000 setpixel [5,211500]
oscsend 127.0.0.1 8000 setpixel [6,211600]
oscsend 127.0.0.1 8000 setpixel [7,211700]
oscsend 127.0.0.1 8000 setpixel [8,211800]
oscsend 127.0.0.1 8000 setpixel [9,211900]

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.05
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.05

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.05
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.05

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.05
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.05

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.05
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.05

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.05
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.05

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.05
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.05


oscsend 127.0.0.1 8000 fadeto [0,100]
oscsend 127.0.0.1 8000 fadeto [1,100]
oscsend 127.0.0.1 8000 fadeto [2,100]

sleep 2

oscsend 127.0.0.1 8000 fadeto [1,100]
oscsend 127.0.0.1 8000 fadeto [2,100]

