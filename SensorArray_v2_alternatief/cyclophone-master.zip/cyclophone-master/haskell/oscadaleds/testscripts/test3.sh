
oscsend 127.0.0.1 8000 updatearray [0]
oscsend 127.0.0.1 8000 setpixel [0,100]
oscsend 127.0.0.1 8000 setpixel [1,1100]
oscsend 127.0.0.1 8000 setpixel [2,1200]
oscsend 127.0.0.1 8000 setpixel [3,1300]
oscsend 127.0.0.1 8000 setpixel [4,1400]
oscsend 127.0.0.1 8000 setpixel [5,1500]
oscsend 127.0.0.1 8000 setpixel [6,1600]
oscsend 127.0.0.1 8000 setpixel [7,1700]
oscsend 127.0.0.1 8000 setpixel [8,1800]
oscsend 127.0.0.1 8000 setpixel [9,1900]

oscsend 127.0.0.1 8000 updatearray [1]
oscsend 127.0.0.1 8000 setpixel [0,1100]
oscsend 127.0.0.1 8000 setpixel [1,11100]
oscsend 127.0.0.1 8000 setpixel [2,11200]
oscsend 127.0.0.1 8000 setpixel [3,11300]
oscsend 127.0.0.1 8000 setpixel [4,11400]
oscsend 127.0.0.1 8000 setpixel [5,11500]
oscsend 127.0.0.1 8000 setpixel [6,11600]
oscsend 127.0.0.1 8000 setpixel [7,11700]
oscsend 127.0.0.1 8000 setpixel [8,11800]
oscsend 127.0.0.1 8000 setpixel [9,11900]

oscsend 127.0.0.1 8000 showarray [0]
sleep 0.5
oscsend 127.0.0.1 8000 showarray [1]
sleep 0.5

