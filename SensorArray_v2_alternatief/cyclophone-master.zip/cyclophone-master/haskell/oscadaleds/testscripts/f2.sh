oscsend 127.0.0.1 8000 showarray [4]
oscsend 127.0.0.1 8000 fadeto [1,50]
oscsend 127.0.0.1 8000 fadeto [4,50]
