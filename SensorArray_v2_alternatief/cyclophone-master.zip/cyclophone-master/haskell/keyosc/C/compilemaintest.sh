g++ -Wall -o main main.c spidevice.c
#gcc -Wall -o main main.c libspidevice.a 
