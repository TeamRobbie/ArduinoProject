# ./osc24 -osc --device hw:1
./osc24 --device hw:1
