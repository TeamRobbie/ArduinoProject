g++ -o ledoscarduino ledoscarduino.c -llo

