#!/bin/bash
g++ -O2 -o cyclosensors main.cpp spidevice.cpp cyclomap.cpp -llo
