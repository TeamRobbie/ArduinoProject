# load spi buses as devices in /dev 
gpio load spi
