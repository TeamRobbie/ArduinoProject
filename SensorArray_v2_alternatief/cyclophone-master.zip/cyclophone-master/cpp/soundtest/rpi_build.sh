g++ main.cpp -I/usr/include/SDL -D_GNU_SOURCE=1 -D_REENTRANT -L/usr/lib/arm-linux-gnueabihf -o sdltest -lSDL -lSDL_mixer

